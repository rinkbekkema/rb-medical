-- Inventory compatibility layer (qs-inventory).
-- Provides minimal functions used by this resource, without hard-depending on ox inventory.

Inventory = Inventory or {}

---Returns item count (number) or 0.
---@param item string
function Inventory.Count(item)
    if GetResourceState('qs-inventory') ~= 'started' then return 0 end

    -- Quasar inventory commonly provides Search export (returns qty or nil).
    local ok, qty = pcall(function()
        return exports['qs-inventory']:Search('count', item)
    end)
    if ok and type(qty) == 'number' then return qty end

    ok, qty = pcall(function()
        return exports['qs-inventory']:Search(item)
    end)
    if ok and type(qty) == 'number' then return qty end

    ok, qty = pcall(function()
        return exports['qs-inventory']:HasItem(item)
    end)
    if ok then
        if type(qty) == 'boolean' then return qty and 1 or 0 end
        if type(qty) == 'number' then return qty end
    end

    return 0
end

---@param item string
function Inventory.HasItem(item)
    return Inventory.Count(item) > 0
end

---Open a stash (qs-inventory / qb-inventory style compatibility).
---@param stashName string
---@param opts table|nil
function Inventory.OpenStash(stashName, opts)
    opts = opts or {}
    TriggerEvent('inventory:client:SetCurrentStash', stashName)
    TriggerServerEvent('inventory:server:OpenInventory', 'stash', stashName, opts)
end

---Open a shop.
---@param shopName string
function Inventory.OpenShop(shopName)
    TriggerServerEvent('inventory:openShop', shopName)
end
