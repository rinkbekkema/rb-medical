BODY_PART_STATE_BAG_PREFIX = 'qbx_medical:injuries:'
BLEED_LEVEL_STATE_BAG = 'qbx_medical:bleedLevel'
DEATH_STATE_STATE_BAG = 'qbx_medical:deathState'