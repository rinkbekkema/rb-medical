\
-- Minimal QBX compatibility helpers used by the original scripts.
qbx = qbx or {}

---@param coords vector3
---@return {main: string, cross: string}
function qbx.getStreetName(coords)
    local streetHash, crossHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local main = GetStreetNameFromHashKey(streetHash)
    local cross = crossHash ~= 0 and GetStreetNameFromHashKey(crossHash) or ''
    return { main = main, cross = cross }
end

function qbx.drawText2d(text, x, y)
    SetTextFont(4)
    SetTextScale(0.35, 0.35)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x or 0.5, y or 0.5)
end

---@param vehicle number
---@param extras table<number, boolean>
function qbx.setVehicleExtras(vehicle, extras)
    if not DoesEntityExist(vehicle) then return end
    for id, enabled in pairs(extras or {}) do
        SetVehicleExtra(vehicle, id, not enabled)
    end
end
