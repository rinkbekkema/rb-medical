\
lib.callback.register('qbx_ambulancejob:client:spawnVehicle', function(vehicleName, vehicleCoords)
    local model = joaat(vehicleName)
    if not IsModelInCdimage(model) then return nil end
    lib.requestModel(model, 5000)

    local coords
    if type(vehicleCoords) == 'table' and vehicleCoords.x then
        coords = vector4(vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, vehicleCoords.w or 0.0)
    elseif type(vehicleCoords) == 'vector4' then
        coords = vehicleCoords
    else
        local p = GetEntityCoords(cache.ped)
        coords = vector4(p.x, p.y, p.z, GetEntityHeading(cache.ped))
    end

    local veh = CreateVehicle(model, coords.x, coords.y, coords.z, coords.w, true, true)
    while not DoesEntityExist(veh) do Wait(0) end

    local netId = NetworkGetNetworkIdFromEntity(veh)
    SetNetworkIdCanMigrate(netId, true)

    SetPedIntoVehicle(cache.ped, veh, -1)
    SetVehicleEngineOn(veh, true, true, true)

    return netId
end)
