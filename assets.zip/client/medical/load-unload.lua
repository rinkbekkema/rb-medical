\
local config = require 'config.client'

local function initHealthAndArmor(ped, playerId)
    SetEntityMaxHealth(ped, 200)
    SetPlayerHealthRechargeMultiplier(playerId, 0.0)
    SetPlayerHealthRechargeLimit(playerId, 0.0)
end

local function initDeathAndLastStand()
    -- Death/laststand are driven by statebags; client scripts will pick it up.
end

local function onPlayerLoaded()
    pcall(function() exports.spawnmanager:setAutoSpawn(false) end)
    CreateThread(function()
        Wait(1000)
        initHealthAndArmor(cache.ped, cache.playerId)
        initDeathAndLastStand()
    end)
end

-- ESX event
AddEventHandler('esx:playerLoaded', onPlayerLoaded)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if cache.playerId then onPlayerLoaded() end
end)
