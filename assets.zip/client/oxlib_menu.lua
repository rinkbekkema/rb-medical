local ESX = exports['es_extended']:getSharedObject()
local sharedConfig = require 'config.shared'

local function isEms()
    local data = ESX.GetPlayerData()
    return data and data.job and data.job.name == (sharedConfig.emsJobName or 'ambulance')
end

local function getClosestPlayer(maxDist)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local closest, closestDist = nil, maxDist or 3.0

    for _, ply in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(ply)
        if ped ~= playerPed then
            local dist = #(GetEntityCoords(ped) - coords)
            if dist < closestDist then
                closest = GetPlayerServerId(ply)
                closestDist = dist
            end
        end
    end
    return closest
end

local function openEmsMenu()
    if not isEms() then
        lib.notify({ title = 'EMS', description = (locale('error.not_ems') or 'Not EMS'), type = 'error' })
        return
    end

    lib.registerContext({
        id = 'ems_menu',
        title = 'EMS',
        options = {
            {
                title = (locale('menu.revive_nearest') or 'Revive nearest'),
                icon = 'heart-pulse',
                onSelect = function()
                    local target = getClosestPlayer(3.0)
                    if not target then return lib.notify({description = 'No one nearby', type='error'}) end
                    TriggerServerEvent('ems:server:revive', target)
                end
            },
            {
                title = (locale('menu.heal_nearest') or 'Treat wounds (full)'),
                icon = 'kit-medical',
                onSelect = function()
                    local target = getClosestPlayer(3.0)
                    if not target then return lib.notify({description = 'No one nearby', type='error'}) end
                    TriggerServerEvent('ems:server:treat', target, 'full')
                end
            },
            {
                title = (locale('menu.check_in') or 'Check-in self'),
                icon = 'bed',
                onSelect = function()
                    TriggerEvent('qbx_ambulancejob:client:openCheckIn')
                end
            }
        }
    })

    lib.showContext('ems_menu')
end

RegisterCommand('ems', openEmsMenu, false)
