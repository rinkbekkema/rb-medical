\
local sharedConfig = require 'config.shared'

---@class Injury
---@field severity integer
---@field weaponHash number

local function getDeathStateFromState(src)
    -- If state already has it, keep it; otherwise default alive
    local state = Player(src).state
    return state[DEATH_STATE_STATE_BAG] or sharedConfig.deathState.ALIVE
end

local function initPlayerState(src)
    local playerState = Player(src).state
    playerState:set(DEATH_STATE_STATE_BAG, getDeathStateFromState(src), true)
    playerState:set(BLEED_LEVEL_STATE_BAG, 0, true)
    for bodyPartKey in pairs(sharedConfig.bodyParts) do
        playerState:set(BODY_PART_STATE_BAG_PREFIX .. bodyPartKey, nil, true)
    end
    playerState:set("isDead", false, true)
end

-- ESX player loaded (signature differs by ESX versions; handle both)
AddEventHandler('esx:playerLoaded', function(playerId)
    if type(playerId) ~= 'number' then
        -- some versions pass xPlayer only; fallback to source
        playerId = source
    end
    initPlayerState(playerId)
end)

AddEventHandler('playerJoining', function()
    initPlayerState(source)
end)

AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, id in ipairs(GetPlayers()) do
        initPlayerState(tonumber(id))
    end
end)

AddStateBagChangeHandler(DEATH_STATE_STATE_BAG, nil, function(bagName, _, value)
    local playerId = GetPlayerFromStateBagName(bagName)
    if not playerId then return end
    Player(playerId).state:set("isDead", value == sharedConfig.deathState.DEAD or value == sharedConfig.deathState.LAST_STAND, true)
end)

---@param playerId number
local function revivePlayer(playerId)
    TriggerClientEvent('qbx_medical:client:playerRevived', playerId)
end
exports('Revive', revivePlayer)

---@param playerId number
local function heal(playerId)
    TriggerClientEvent('qbx_medical:client:heal', playerId, 'full')
end
exports('Heal', heal)

---@param playerId number
local function healPartially(playerId)
    TriggerClientEvent('qbx_medical:client:heal', playerId, 'partial')
end
exports('HealPartially', healPartially)

local function getPlayerInjuries(state)
    local injuries = {}
    for bodyPartKey in pairs(sharedConfig.bodyParts) do
        injuries[bodyPartKey] = state[BODY_PART_STATE_BAG_PREFIX .. bodyPartKey]
    end
    return injuries
end

---@param src number
---@return {injuries: string[], bleedLevel: integer, bleedState: string, damageCauses: table<number, true>}
local function getPlayerStatus(src)
    local state = Player(src).state
    local bleedLevel = state[BLEED_LEVEL_STATE_BAG] or 0
    local injuries = getPlayerInjuries(state)

    local injuryStatuses = {}
    local weaponsThatDamagedPlayer = {}
    local i = 0

    for bodyPartKey, injury in pairs(injuries) do
        if injury then
            local bodyPart = sharedConfig.bodyParts[bodyPartKey]
            i += 1
            injuryStatuses[i] = bodyPart.label .. ' (' .. sharedConfig.woundLevels[injury.severity].label .. ')'
            weaponsThatDamagedPlayer[injury.weaponHash] = true
        end
    end

    return {
        injuries = injuryStatuses,
        bleedLevel = bleedLevel,
        bleedState = sharedConfig.bleedingStates[bleedLevel] or sharedConfig.bleedingStates[0],
        damageCauses = weaponsThatDamagedPlayer
    }
end

exports('GetPlayerStatus', getPlayerStatus)

-- Optional status reset hooks (works if esx_status is present)
lib.callback.register('qbx_medical:server:resetHungerAndThirst', function(source)
    if GetResourceState('esx_status') ~= 'started' then return end
    TriggerClientEvent('esx_status:set', source, 'hunger', 1000000)
    TriggerClientEvent('esx_status:set', source, 'thirst', 1000000)
end)

-- txAdmin heal compatibility
AddEventHandler('txAdmin:events:healedPlayer', function(eventData)
    if GetInvokingResource() ~= 'monitor' or type(eventData) ~= 'table' or type(eventData.id) ~= 'number' then
        return
    end
    revivePlayer(eventData.id)
    heal(eventData.id)
end)

-- Admin commands (ACE: command.revive / command.aheal / command.kill)
RegisterCommand('revive', function(source, args)
    local target = tonumber(args[1]) or source
    if source ~= 0 and not IsPlayerAceAllowed(source, 'command.revive') then return end
    revivePlayer(target)
end, false)

RegisterCommand('aheal', function(source, args)
    local target = tonumber(args[1]) or source
    if source ~= 0 and not IsPlayerAceAllowed(source, 'command.aheal') then return end
    heal(target)
end, false)

RegisterCommand('kill', function(source, args)
    local target = tonumber(args[1]) or source
    if source ~= 0 and not IsPlayerAceAllowed(source, 'command.kill') then return end
    lib.callback.await('qbx_medical:client:killPlayer', target)
end, false)

lib.callback.register('qbx_medical:server:respawn', function(source)
    TriggerEvent('qbx_medical:server:playerRespawned', source)
    return true
end)
