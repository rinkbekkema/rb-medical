\
local ESX = exports['es_extended']:getSharedObject()
local sharedConfig = require 'config.shared'

local function isEms(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return false end
    return xPlayer.job and xPlayer.job.name == (sharedConfig.emsJobName or 'ambulance')
end

lib.callback.register('qbx_ambulancejob:server:getPlayerStatus', function(_, targetSrc)
    return exports[GetCurrentResourceName()]:GetPlayerStatus(targetSrc)
end)

local function alertAmbulance(src, text)
    local ped = GetPlayerPed(src)
    local coords = GetEntityCoords(ped)

    for _, pid in ipairs(ESX.GetPlayers()) do
        local xP = ESX.GetPlayerFromId(pid)
        if xP and xP.job and xP.job.name == (sharedConfig.emsJobName or 'ambulance') then
            TriggerClientEvent('hospital:client:ambulanceAlert', pid, coords, text)
        end
    end
end

RegisterNetEvent('hospital:server:ambulanceAlert', function(text)
    if GetInvokingResource() then return end
    alertAmbulance(source, text or locale('info.civ_down'))
end)

RegisterNetEvent('hospital:server:emergencyAlert', function()
    if GetInvokingResource() then return end
    alertAmbulance(source, locale('info.ems_down', 'EMS'))
end)

RegisterNetEvent('qbx_medical:server:onPlayerLaststand', function()
    if GetInvokingResource() then return end
    alertAmbulance(source, locale('info.civ_down'))
end)

RegisterNetEvent('hospital:server:TreatWounds', function(playerId)
    if GetInvokingResource() then return end
    local src = source
    if not isEms(src) then return end
    if not ESX.GetPlayerFromId(playerId) then return end

    if GetResourceState('qs-inventory') == 'started' then
        exports.qs-inventory:RemoveItem(src, 'bandage', 1)
    end
    TriggerClientEvent('hospital:client:HealInjuries', playerId, 'full')
end)

RegisterNetEvent('hospital:server:RevivePlayer', function(playerId)
    if GetInvokingResource() then return end
    local src = source
    if not isEms(src) then return end
    if not ESX.GetPlayerFromId(playerId) then return end

    if GetResourceState('qs-inventory') == 'started' then
        exports.qs-inventory:RemoveItem(src, 'firstaid', 1)
    end
    TriggerClientEvent('qbx_medical:client:playerRevived', playerId)
end)

RegisterNetEvent('hospital:server:UseFirstAid', function(targetId)
    if GetInvokingResource() then return end
    local src = source
    if not ESX.GetPlayerFromId(targetId) then return end

    local canHelp = lib.callback.await('hospital:client:canHelp', targetId)
    if not canHelp then
        TriggerClientEvent('ox_lib:notify', src, {description = locale('error.cant_help'), type='error'})
        return
    end
    TriggerClientEvent('hospital:client:HelpPerson', src, targetId)
end)

lib.callback.register('qbx_ambulancejob:server:getNumDoctors', function()
    local count = 0
    for _, pid in ipairs(ESX.GetPlayers()) do
        local xP = ESX.GetPlayerFromId(pid)
        if xP and xP.job and xP.job.name == (sharedConfig.emsJobName or 'ambulance') then
            count += 1
        end
    end
    return count
end)

RegisterCommand('911e', function(source, args)
    local message = table.concat(args, ' ')
    if message == '' then message = locale('info.civ_call') end
    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    for _, pid in ipairs(ESX.GetPlayers()) do
        local xP = ESX.GetPlayerFromId(pid)
        if xP and xP.job and xP.job.name == (sharedConfig.emsJobName or 'ambulance') then
            TriggerClientEvent('hospital:client:ambulanceAlert', pid, coords, message)
        end
    end
end, false)

-- ox_lib menu server events
RegisterNetEvent('ems:server:revive', function(targetId)
    if not isEms(source) then return end
    TriggerClientEvent('qbx_medical:client:playerRevived', targetId)
end)

RegisterNetEvent('ems:server:treat', function(targetId, mode)
    if not isEms(source) then return end
    TriggerClientEvent('qbx_medical:client:heal', targetId, mode or 'full')
end)


-- EMS billing helpers
local function billTarget(targetId, amount)
    local xTarget = ESX.GetPlayerFromId(targetId)
    if not xTarget then return end
    xTarget.removeAccountMoney('bank', amount)
end

RegisterNetEvent('ems:server:revive', function(targetId)
    if not isEms(source) then return end
    billTarget(targetId, sharedConfig.Pricing.revive)
    TriggerClientEvent('qbx_medical:client:playerRevived', targetId)
end)

RegisterNetEvent('ems:server:treat', function(targetId)
    if not isEms(source) then return end
    billTarget(targetId, sharedConfig.Pricing.treat)
    TriggerClientEvent('qbx_medical:client:heal', targetId, 'partial')
end)
