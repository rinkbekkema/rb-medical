\
local ESX = exports['es_extended']:getSharedObject()
local config = require 'config.server'
local sharedConfig = require 'config.shared'

local doctorCalled = false

---@type table<string, table<number, boolean>>
local hospitalBedsTaken = {}

for hospitalName, hospital in pairs(sharedConfig.locations.hospitals) do
    hospitalBedsTaken[hospitalName] = {}
    for i = 1, #hospital.beds do
        hospitalBedsTaken[hospitalName][i] = false
    end
end

local function getOpenBed(hospitalName)
    local beds = hospitalBedsTaken[hospitalName]
    for i = 1, #beds do
        if not beds[i] then return i end
    end
end

lib.callback.register('qbx_ambulancejob:server:getOpenBed', function(_, hospitalName)
    return getOpenBed(hospitalName)
end)

local function societyDeposit(amount)
    if type(config.depositSociety) == 'function' then
        -- if user kept their own society handler
        return config.depositSociety('ambulance', amount)
    end

    if GetResourceState('esx_addonaccount') ~= 'started' then return end
    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_ambulance', function(account)
        if account then account.addMoney(amount) end
    end)
end

local function billPlayer(src)
    local price = sharedConfig.Pricing.hospitalCheckIn
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end
    xPlayer.removeAccountMoney('bank', price)
    societyDeposit(price)
    TriggerClientEvent('hospital:client:SendBillEmail', src, price)
end

RegisterNetEvent('qbx_ambulancejob:server:playerEnteredBed', function(hospitalName, bedIndex)
    if GetInvokingResource() then return end
    local src = source
    billPlayer(src)
    if hospitalBedsTaken[hospitalName] then
        hospitalBedsTaken[hospitalName][bedIndex] = true
    end
end)

RegisterNetEvent('qbx_ambulancejob:server:playerLeftBed', function(hospitalName, bedIndex)
    if GetInvokingResource() then return end
    if hospitalBedsTaken[hospitalName] then
        hospitalBedsTaken[hospitalName][bedIndex] = false
    end
end)

RegisterNetEvent('hospital:server:putPlayerInBed', function(playerId, hospitalName, bedIndex)
    if GetInvokingResource() then return end
    TriggerClientEvent('qbx_ambulancejob:client:putPlayerInBed', playerId, hospitalName, bedIndex)
end)

lib.callback.register('qbx_ambulancejob:server:isBedTaken', function(_, hospitalName, bedIndex)
    return hospitalBedsTaken[hospitalName] and hospitalBedsTaken[hospitalName][bedIndex] or false
end)

local function wipeInventory(src)
    if GetResourceState('qs-inventory') == 'started' then
        exports.qs-inventory:ClearInventory(src)
    end
    TriggerClientEvent('ox_lib:notify', src, {description = locale('error.possessions_taken') or 'Your possessions were taken.', type='error'})
end

-- Vehicle spawn: ask client to spawn using ESX.Game.SpawnVehicle if available, else natives.
lib.callback.register('qbx_ambulancejob:server:spawnVehicle', function(source, vehicleName, vehicleCoords)
    return lib.callback.await('qbx_ambulancejob:client:spawnVehicle', source, vehicleName, vehicleCoords)
end)

local function sendDoctorAlert()
    if doctorCalled then return end
    doctorCalled = true
    for _, pid in ipairs(ESX.GetPlayers()) do
        local xP = ESX.GetPlayerFromId(pid)
        if xP and xP.job and xP.job.name == (sharedConfig.emsJobName or 'ambulance') then
            TriggerClientEvent('ox_lib:notify', pid, {description = locale('info.dr_needed') or 'Doctor needed at hospital', type='inform'})
        end
    end

    SetTimeout((config.doctorCallCooldown or 10) * 60000, function()
        doctorCalled = false
    end)
end

local function canCheckIn(source, hospitalName)
    local numDoctors = 0
    for _, pid in ipairs(ESX.GetPlayers()) do
        local xP = ESX.GetPlayerFromId(pid)
        if xP and xP.job and xP.job.name == (sharedConfig.emsJobName or 'ambulance') then
            numDoctors += 1
        end
    end

    if numDoctors >= sharedConfig.minForCheckIn then
        TriggerClientEvent('ox_lib:notify', source, {description = locale('info.dr_alert') or 'A doctor is on duty, please wait.', type='inform'})
        sendDoctorAlert()
        return false
    end

    return true
end

lib.callback.register('qbx_ambulancejob:server:canCheckIn', canCheckIn)

local function checkIn(src, patientSrc, hospitalName)
    if src == patientSrc and not canCheckIn(patientSrc, hospitalName) then return false end

    local bedIndex = getOpenBed(hospitalName)
    if not bedIndex then
        TriggerClientEvent('ox_lib:notify', src, {description = locale('error.beds_taken') or 'All beds taken.', type='error'})
        return false
    end

    TriggerClientEvent('qbx_ambulancejob:client:checkedIn', patientSrc, hospitalName, bedIndex)
    return true
end

lib.callback.register('qbx_ambulancejob:server:checkIn', checkIn)
exports('CheckIn', checkIn)

local function respawn(src)
    local closestHospital = 'pillbox'
    local coords = GetEntityCoords(GetPlayerPed(src))
    local closestDist

    for hospitalName, hospital in pairs(sharedConfig.locations.hospitals) do
        if hospitalName ~= 'jail' then
            local d = #(coords - hospital.coords)
            if not closestDist or d < closestDist then
                closestDist = d
                closestHospital = hospitalName
            end
        end
    end

    local bedIndex = getOpenBed(closestHospital)
    if not bedIndex then
        TriggerClientEvent('ox_lib:notify', src, {description = locale('error.beds_taken') or 'All beds taken.', type='error'})
        return
    end

    TriggerClientEvent('qbx_ambulancejob:client:checkedIn', src, closestHospital, bedIndex)

    if config.wipeInvOnRespawn then
        wipeInventory(src)
    end
end

AddEventHandler('qbx_medical:server:playerRespawned', respawn)
